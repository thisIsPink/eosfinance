<?php
//000000000000
 exit();?>
{"type":"email","name":"19345111@qq.com"}