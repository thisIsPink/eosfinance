<?php
//000000000000
 exit();?>
{"type":"email","name":"1353880213@qq.com"}