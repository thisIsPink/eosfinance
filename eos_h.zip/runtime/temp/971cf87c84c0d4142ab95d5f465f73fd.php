<?php /*a:1:{s:63:"/www/wwwroot/eos_ht/application/admin/view/index/wheel_img.html";i:1557912888;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
    <style type="text/css">
      .layui-table-cell{height: auto;}
    </style>
  </head>
  
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">公司管理</a>
        <a>
          <cite>首页轮播</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <xblock>
        <button type="button" class="layui-btn" id="test1">
          <i class="layui-icon">&#xe67c;</i>上传图片
        </button>
      </xblock>
      <table class="layui-table" id="notify_list" lay-filter="notify_list"></table>
      <script type="text/html" id="notify_bar">
         <a onclick="del('{{d.id}}')" href="javascript:;" class="layui-btn layui-btn-danger">删除</a>
      </script>
    </div>
    <script>
      layui.use(['upload',"table"],function(){
        var table = layui.table;
        var upload = layui.upload;
        var tableIns=table.render({
          elem: '#notify_list'
          ,height: 420
          ,url: 'json/wheel_img' //数据接口
          ,cols: [[ //表头
            {field: 'id', title: 'ID', width:100}
            ,{field: 'url', title: '图片',templet: '<div><img src="/static/public/img/wheel/{{d.url}}"></div>'}
            ,{field: 'herf', title: '跳转',edit: 'text'}
            ,{title:'操作', toolbar: '#notify_bar'}
          ]]
        });
        upload.render({
          elem: '#test1' //绑定元素
          ,url: 'sub/wheel_img_upload' //上传接口
          ,accept:"images"
          ,acceptMime:"image/*"
          ,done: function(res){
            layer.msg("上传成功",{time:1200},function(){
              location.replace(location.href);
            });
          }
          ,error: function(){
            layer.msg("上传出错");
          }
        });
        table.on('edit(notify_list)', function(obj){
          $.ajax({
            url: 'sub/img_edit',
            type: 'post',
            dataType: 'json',
            data: {"value": obj.value,"id":obj.data.id},
            success:function(msg){
              if(msg.flag=="true"){
                layer.msg("修改成功");
              }else{
                layer.msg(msg.msg);
              }
            }
          })
        });
      })
      function del(id) {
        layer.confirm('确认要删除吗？',function(index){
          $.ajax({
            url: 'sub/img_del',
            type: 'post',
            dataType: 'json',
            data: {"id":id},
            success:function(msg){
              if(msg.flag=="true"){
                layer.msg("删除成功",{time:1200},function(){
                  location.replace(location.href);
                });
              }else{
                layer.msg(msg.msg);
              }
            }
          });
        })
      }
    </script>
  </body>

</html>