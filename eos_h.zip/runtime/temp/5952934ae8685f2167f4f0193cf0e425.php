<?php /*a:1:{s:70:"/www/wwwroot/eos_ht/application/admin/view/index/member_login_log.html";i:1557910472;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body class="">
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">会员管理</a>
        <a>
          <cite>用户登陆情况</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <div class="layui-row">
        <form class="layui-form layui-col-md12 x-so">
          <input type="text" name="id"  placeholder="请输入ID" autocomplete="off" class="layui-input" value="">
          <input type="text" name="name"  placeholder="请输入用户名" autocomplete="off" class="layui-input" value="">
          <input type="text" name="phone"  placeholder="请输入用户电话" autocomplete="off" class="layui-input" value="">
          <input type="text" name="email"  placeholder="请输入用户邮箱" autocomplete="off" class="layui-input" value="">
          <input class="layui-input"  autocomplete="off" placeholder="开始日" name="start" id="start">
          <input class="layui-input"  autocomplete="off" placeholder="截止日" name="end" id="end">
          <button class="layui-btn"  lay-submit="" lay-filter="sreach"><i class="layui-icon">&#xe615;</i></button>
        </form>
      </div>
      <table class="layui-table" id="user_login" lay-filter="user_login"></table>

    </div>
    <script>
      layui.use(['table','laydate','form'],function(){
        var table = layui.table;
        var laydate = layui.laydate;
        var form = layui.form;
        var tableIns=table.render({
          elem: '#user_login'
          ,height: 400
          ,url: '/admin/json/user_log' //数据接口
          ,page: true //开启分页
          ,cols: [[ //表头
            {field: 'id', title: '用户ID', sort: true, fixed: 'left'}
            ,{field: 'account', title: 'EOS账号'}
            ,{field: 'time', title: '时间',templet: '<div>{{getLocalTime(d.time)}}</div>'}
            ,{field: 'ip', title: 'IP地址'} 
            ,{field: 'state', title: '状态',templet: '<div>{{d.state == "1" ? "登陆" : "未知"}}</div>'}
          ]]
        });
        laydate.render({
          elem: '#start', //指定元素
          type: 'datetime'
        });
        laydate.render({
          elem: '#end', //指定元素
          type: 'datetime'
          ,done: function(value){
            var start=Date.parse(new Date($('[name="start"]').val()));
            if(new Date(value)-start<0){
              layer.msg("结束时间不能小于开始时间");
              return;
            }
          }
        });
        form.on('submit(sreach)', function(data){
          if(data.field.start!=""||data.field.end!=''){
            if(data.field.start!=""&&data.field.end!=''){
              var start=Date.parse(new Date($('[name="start"]').val()));
              var end=Date.parse(new Date($('[name="end"]').val()));
              if(end-start<0){
                layer.msg("结束时间不能小于开始时间");
                return false;
              }
            }
            if(data.field.start!=""){
              data.field.start=Date.parse(data.field.start)/1000;
            }
            if(data.field.end!=""){
              data.field.end=Date.parse(data.field.end)/1000;
            }
          }
          tableIns.reload({
            where: data.field
            ,page: {
              curr: 1
            }
          });
          return false; 
        });
      })
      function getLocalTime(nS) {  
        if(nS==null||nS==''){
          return '无';
        }   
         return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');     
      }
    </script>
  </body>

</html>