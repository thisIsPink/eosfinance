<?php /*a:1:{s:58:"/www/wwwroot/eos_h/application/admin/view/index/index.html";i:1557909812;}*/ ?>
<!doctype html>
<html  class="x-admin-sm">
<head>
	<meta charset="UTF-8">
	<title>eosinvestmentbank超级后台</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
	<link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <!-- <script type="text/javascript"src="https://cdn.bootcss.com/blueimp-md5/2.10.0/js/md5.min.js"></script> -->
    <script src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>

    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
    <script>
        // 是否开启刷新记忆tab功能
        // var is_remember = false;
    </script>
</head>
<body>
    <!-- 顶部开始 -->
    <div class="container">
        <div class="logo"><a href="./index">EOS后台管理系统</a></div>
        <div class="left_open">
            <i title="展开左侧栏" class="iconfont">&#xe699;</i>
        </div>
        <ul class="layui-nav right" lay-filter="">
          <li class="layui-nav-item">
            <a href="javascript:;"><?php echo htmlentities(app('request')->session('admin')); ?></a>
            <dl class="layui-nav-child"> <!-- 二级菜单 -->
              <!-- <dd><a onclick="x_admin_show('个人信息','http://www.baidu.com')">个人信息</a></dd>
              <dd><a onclick="x_admin_show('切换帐号','http://www.baidu.com')">切换帐号</a></dd> -->
              <dd><a id="admin_out">退出</a></dd>
            </dl>
          </li>
          <li class="layui-nav-item to-index"><a href="https://www.eosinvestmentbank.com/">前台首页</a></li>
        </ul>
        
    </div>
    <!-- 顶部结束 -->
    <!-- 中部开始 -->
     <!-- 左侧菜单开始 -->
    <div class="left-nav">
      <div id="side-nav">
        <ul id="nav">
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6b8;</i>
                    <cite>会员管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li date-refresh="1">
                        <a _href="member_list">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>用户查看</cite>
                            
                        </a>
                    </li >
                    <li>
                        <a _href="member_login_log">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>用户登陆情况</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="inviter">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>用户邀请情况</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="super_user">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>超级邀请人管理</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe723;</i>
                    <cite>投标管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="order_list">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>发布管理标</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="bid_tender_record">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>投标记录</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="profit">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>分利情况</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="repay">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>还款情况</cite>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe723;</i>
                    <cite>货币管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="coin">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>管理</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe723;</i>
                    <cite>信息中心</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="notice">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>公告管理</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="notify">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>通知发送</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe726;</i>
                    <cite>管理员管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="admin_list">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>管理员列表</cite>
                        </a>
                    </li >
                    <!-- <li>
                        <a _href="admin-role">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>角色管理</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="admin-cate">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>权限分类</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="admin-rule">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>权限管理</cite>
                        </a>
                    </li > -->
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6ce;</i>
                    <cite>公司管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="company">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>公司账号设置</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="wheel_img">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>首页轮播</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="about">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>关于我们</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6b4;</i>
                    <cite>帮助中心</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="financial">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>理财中心</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="operation_process">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>操作流程</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="account_problem">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>账户问题</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="security">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>安全问题</cite>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6b4;</i>
                    <cite>交易中心</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="binding">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>绑定账号</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="recharge">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>充值消息</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="cash">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>提币申请</cite>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
      </div>
    </div>
    <!-- <div class="x-slide_left"></div> -->
    <!-- 左侧菜单结束 -->
    <!-- 右侧主体开始 -->
    <div class="page-content">
        <div class="layui-tab tab" lay-filter="xbs_tab" lay-allowclose="false">
          <ul class="layui-tab-title">
            <li class="home"><i class="layui-icon">&#xe68e;</i>我的桌面</li>
          </ul>
          <div class="layui-unselect layui-form-select layui-form-selected" id="tab_right">
                <dl>
                    <dd data-type="this">关闭当前</dd>
                    <dd data-type="other">关闭其它</dd>
                    <dd data-type="all">关闭全部</dd>
                </dl>
          </div>
          <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <iframe src='welcome' frameborder="0" scrolling="yes" class="x-iframe"></iframe>
            </div>
          </div>
          <div id="tab_show"></div>
        </div>
    </div>
    <div class="page-content-bg"></div>
    <!-- 右侧主体结束 -->
    <!-- 中部结束 -->
    <!-- 底部开始 -->
    <div class="footer">
        <div class="copyright">eosfinace</div>  
    </div>
    <!-- 底部结束 -->
    <script type="text/javascript">
        $('#admin_out').click(function(event) {
            $.post('/admin/admin_out', function() {
                location.href="/admin";
            });
        });
    </script>
</body>
</html>