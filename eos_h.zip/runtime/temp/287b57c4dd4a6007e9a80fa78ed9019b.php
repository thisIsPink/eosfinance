<?php /*a:1:{s:59:"/www/wwwroot/eos_ht/application/admin/view/index/about.html";i:1557912934;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>

    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
    <script type="text/javascript" src="/static/admin/lib/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" src="/static/admin/lib/ueditor/ueditor.all.min.js"></script>
  </head>
  
  <body>
    <tool class="layui-hide" id="about_text"><?php echo htmlentities($data['about']); ?></tool>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">公司管理</a>
        <a>
          <cite>关于我们</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body" style="width: 600px;">
        <script id="editor" type="text/plain"><?php echo htmlentities($data['about']); ?></script>
        <button class="layui-btn input_text">修改</button>
    </div>
    <script type="text/javascript">
      layui.use(['layedit'], function(){
        var upload = layui.upload

      //   ,layedit = layui.layedit;     
       	
      //  	layedit.set({
  			 //  uploadImage: {
    		// 		url: '<?php echo url("sub/about_img"); ?>' //接口url
    		// 		,type: 'post' //默认post
    		// 	}
    		// });
      //  	var buile_details=layedit.build('about',{height:470});
        var ue = UE.getEditor('editor',{
          toolbars: [
              ['bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'removeformat', 'formatmatch', 'autotypeset', '|', 'forecolor','fontsize', 'backcolor', 'selectall', 'cleardoc','link','unlink','simpleupload', '|','justifyleft','justifycenter','justifyright']
          ],
          initialFrameHeight:450,
          initialFrameWidth: 600,
          enableAutoSave :false
        });
        ue.ready(function() {
          ue.setContent($("#about_text").text());
        });

        
       	$(".input_text").click(function(){
          var html;
          ue.ready(function() {
              html = ue.getContent();
          });
	        $.ajax({
	          url: 'sub/about_edit',
	          type: 'post',
	          dataType: 'json',
	          data: {"content": html},
	          success:function(msg){
	            if(msg.flag=="true"){
	              layer.msg("修改成功");
	            }else{
	              layer.msg(msg.msg);
	            }
	          }
	        });
	      })
      });      
    </script>
  </body>

</html>