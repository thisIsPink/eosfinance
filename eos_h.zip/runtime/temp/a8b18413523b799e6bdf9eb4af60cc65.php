<?php /*a:1:{s:62:"/www/wwwroot/eos_ht/application/admin/view/index/coin_add.html";i:1557911110;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body>
    <div class="x-body">
        <form class="layui-form">
          <div class="layui-form-item">
              <label for="username" class="layui-form-label">
                  <span class="x-red">*</span>币种
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="type" name="type" required="" lay-verify="required"
                  autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^[A-Za-z]+$/)'>
              </div>
              <div class="layui-form-mid layui-word-aux">
                  <span class="x-red">*</span>已发行的货币
              </div>
          </div>
          <div class="layui-form-item">
              <label for="phone" class="layui-form-label">
                  <span class="x-red">*</span>最小单位
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="min_company" name="min_company" required="" lay-verify="required" autocomplete="off" class="layui-input" oninput="var v=this.value||'';v=v.replace(/[^\d]/g,'');if(v.length==1 && v==0){v=''};this.value=v.substr(0,2);">
              </div>
              <div class="layui-form-mid layui-word-aux">
                  <span class="x-red">*</span>小数点后几位
              </div>
          </div> 
          <div>
              <div class="layui-form-item">
              <label for="L_email" class="layui-form-label">
                  <span class="x-red">*</span>最少充值
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="min_recharge" name="min_recharge" autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^\d+(?:\.\d{0,100})?/)'>
              </div>
              <div class="layui-form-mid layui-word-aux">
                  默认为0
              </div>
          </div>
          <div> 
              <div class="layui-form-item">
              <label for="L_email" class="layui-form-label">
                  <span class="x-red">*</span>最大充值
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="max_recharge" name="max_recharge" autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^\d+(?:\.\d{0,100})?/)'>
              </div>
              <div class="layui-form-mid layui-word-aux">
                  默认为-1(无上限)
              </div>
          </div>
          <div class="layui-form-item">
              <label class="layui-form-label" style="width: 90px"><span class="x-red">*</span>是否为小额币种</label>
              <div class="layui-input-block">
                <input type="checkbox" name="wherther" lay-skin="switch" lay-text="是|否">
              </div>
          </div>
          <div> 
              <div class="layui-form-item">
              <label for="L_email" class="layui-form-label">
                <span class="x-red">*</span>与EOS比例
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="proportion" name="proportion" required="" lay-verify="required" autocomplete="off" class="layui-input" oninput="this.value=this.value.toString().match(/^\d+(?:\.\d{0,5})?/)">
              </div>
              <div class="layui-form-mid layui-word-aux">
                <span class="x-red">*</span>
                当前货币:EOS,n:1(n为输入值)
              </div>
          </div>
          <div class="layui-form-item">
              <label for="L_repass" class="layui-form-label">
              </label>
              <button  class="layui-btn" lay-filter="add" lay-submit="">增加</button>
          </div>
      </form>
    </div>
    <script>
        layui.use(['form','layer'], function(){
            $ = layui.jquery;
          var form = layui.form
          ,layer = layui.layer;
          form.on('submit(add)', function(data){
            var min_recharge=data.field.min_recharge||0;
            var max_recharge=data.field.max_recharge||-1;
            var amount=data.field.wherther?"true":"false";
            $.ajax({
              url: 'sub/coin_add',
              type: 'post',
              dataType: 'json',
              data: {
                "type": data.field.type,
                "min_company":data.field.min_company,
                "min_recharge":min_recharge,
                "max_recharge":max_recharge,
                "amount":amount,
                "proportion":data.field.proportion
              },
              success:function(msg){
                if(msg.flag=="true"){
                  layer.alert("增加成功", {icon: 6},function () {
                      // 获得frame索引
                      var index = parent.layer.getFrameIndex(window.name);
                      //关闭当前frame
                      parent.layer.close(index);
                      // 可以对父窗口进行刷新 
                      x_admin_father_reload();
                  });
                }else{
                  layer.msg(msg.msg);
                }
              }
            });
            
            //发异步，把数据提交给php
            return false;
          });
          
          
        });
    </script>
  </body>

</html>