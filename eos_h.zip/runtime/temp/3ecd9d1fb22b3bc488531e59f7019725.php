<?php /*a:1:{s:71:"/www/wwwroot/eos_ht/application/admin/view/index/operation_process.html";i:1557913082;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">帮助中心</a>
        <a>
          <cite>关于我们</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
        <div class="layui-upload">
          <button type="button" class="layui-btn" id="test1">修改图片</button>
          <div class="layui-upload-list">
            <img class="layui-upload-img" id="demo1" src="/static/public/img/operation_process/1.jpg?">
            <p id="demoText"></p>
          </div>
        </div> 
    </div>
    <script type="text/javascript">
      layui.use('upload', function(){
        var upload = layui.upload;     
          
        //普通图片上传
          var uploadInst = upload.render({
            elem: '#test1'
            ,url: 'sub/help_img_edit'
            ,before: function(obj){
              //预读本地文件示例，不支持ie8
              obj.preview(function(index, file, result){
                $('#demo1').attr('src', result); //图片链接（base64）
              });
            }
          });
      });
    </script>
  </body>

</html>