<?php /*a:1:{s:64:"/www/wwwroot/eos_ht/application/admin/view/index/super_user.html";i:1557911082;}*/ ?>
<html class="x-admin-sm">
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">用户管理</a>
        <a>
          <cite>超级邀请人管理</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <xblock>
        <button class="layui-btn" onclick="x_admin_show('添加用户','super_user_add')"><i class="layui-icon"></i>添加</button>
      </xblock>
      <table id="super_list" lay-filter="super_list" class="layui-table x-admin"></table>
      <script type="text/html" id="member_bar">
        <a onclick="member_stop(this,{{d.id}})" href="javascript:;"  title="{{d.state == '1' ? '正常' : d.state == '2' ? '冻结' : '错误'}}"><i class="layui-icon">
          &#{{d.state == '1' ? 'xe601' : 'xe62f' }};
        </i></a>
      </script>
      <script type="text/html" id="member_state">
        <span class="layui-btn layui-btn-normal layui-btn-mini {{d.state == '1' ? '' : 'layui-btn-disabled'}}">{{d.state == '1' ? '正常' : d.state == '2' ? '冻结' : '错误'}}</span>
      </script>
    </div>
    <script>
      layui.use(['table','form'],function(){
        var table = layui.table;
        var laydate = layui.laydate;
        var form = layui.form;
        var tableIns=table.render({
          elem: '#super_list'
          ,height: 470
          ,url: 'json/super_user' //数据接口
          ,page: true //开启分页
          ,cols: [[ //表头
            {field: 'id', title: 'ID', width:80, sort: true, fixed: 'left'}
            ,{field: 'account', title: 'EOS账号'}
            ,{field: 'phone', title: '电话'}
            ,{field: 'email', title: '邮箱'}
            ,{field: 'proportion', title: '收益比重',edit:"text"}
            ,{field: 'up_login_time', title: '上次登陆时间', sort: true,templet: '<div>{{getLocalTime(d.up_login_time)}}</div>'}
            ,{field: 'state', title: '状态',toolbar:'#member_state'}
            ,{title:'操作', toolbar: '#member_bar'}
          ]]
        });
        table.on('edit(super_list)', function(obj){
          $.ajax({
            url: '<?php echo url("sub/super_propor"); ?>',
            type: 'post',
            dataType: 'json',
            data: {"field": obj.field,"value":obj.value,"id":obj.data.id},
            success:function(msg){
              if(msg.flag=="true"){
                layer.msg("修改成功");
              }else{
                layer.msg("修改失败");
              }
            }
          });
        });
      })
       /*用户-停用*/
      function member_stop(obj,id){
        if($(obj).attr('title')=='正常'){
          layer.confirm('确认要停用吗？',function(index){
            //发异步把用户状态进行更改
            $.ajax({
              url: 'sub/super_state_down',
              type: 'post',
              dataType: 'json',
              data: {"id": id},
              success:function(msg){
                if(msg.flag=="true"){
                  $(obj).attr('title','冻结')
                  $(obj).find('i').html('&#xe62f;');
                  $(obj).parents("tr").find("[data-field='state']").find('div span').addClass('layui-btn-disabled').html('冻结');
                  layer.msg('已冻结!',{icon: 5,time:1000});
                }
              }
            });
          });
        }else if($(obj).attr('title')=='冻结'){
          layer.confirm('确认要启用吗？',function(index){
            $.ajax({
              url: 'sub/super_state_up',
              type: 'post',
              dataType: 'json',
              data: {"id": id},
              success:function(msg){
                if(msg.flag=='true'){
                  $(obj).attr('title','正常')
                  $(obj).find('i').html('&#xe601;');
                  $(obj).parents("tr").find("[data-field='state']").find('span').removeClass('layui-btn-disabled').html('正常');
                  layer.msg('已启用!',{icon: 1,time:1000});
                }
              }
            });
          });
        }else{
          layer.msg('请联系管理员!',{icon: 2,time:1000});
        }
      }
      function getLocalTime(nS) {  
        if(nS==null||nS==''){
          return '无';
        }   
         return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');  
      }
      function info_money(arr){
        var str='';
        for(var i=0;i<arr.length;i++){
          for(key in arr[i]){
            str+='<tr><td>'+key+'</td><td>'+arr[i][key]+'</td></tr>'            
          }
        }
        $("#tool_table tbody").html(str);
        layui.use('layer', function(){
          var layer = layui.layer;
          
          layer.open({
            type: 1, 
            content: $('#tool_table')
          });
        });        
      }
    </script>
  </body>

</html>