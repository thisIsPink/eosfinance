<?php
	//短信国家列表
	return [
		"86"=>'【eosinvestmentbank】您的验证码是：{$code}'
	];
?>