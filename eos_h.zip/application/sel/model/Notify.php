<?php
namespace app\sel\model;
use think\Model;

class Notify extends Model{
	public function sel($page,$limit){
		return db("notify")->field("time,content")->where("state",1)->order("time","desc")->page($page,$limit)->select();
	}
}
?>