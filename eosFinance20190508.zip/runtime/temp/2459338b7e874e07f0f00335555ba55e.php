<?php /*a:1:{s:87:"E:\phpStudy\PHPTutorial\WWW\gongsi\eosFinance\application/admin/view\index\company.html";i:1557304777;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">公司管理</a>
        <a>
          <cite>公司账户设置</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
        <div class="layui-form-item">
          <label class="layui-form-label">EOS账户</label>
          <div class="layui-input-block">
            <input type="text" name="title" required  lay-verify="required" placeholder="请输入EOS账户" autocomplete="off" class="layui-input account" value="<?php echo htmlentities($data['account']); ?>">
          </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">QQ群</label>
          <div class="layui-input-block">
            <input type="text" name="title" required  lay-verify="required" placeholder="请输入QQ群" autocomplete="off" class="layui-input qq" value="<?php echo htmlentities($data['qq']); ?>">
          </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">客服电环</label>
          <div class="layui-input-block">
            <input type="text" name="title" required  lay-verify="required" placeholder="请输入电话" autocomplete="off" class="layui-input phone" value="<?php echo htmlentities($data['phone']); ?>">
          </div>
        </div>
        <div class="layui-upload">
          <button type="button" class="layui-btn" id="test1">修改图片</button>
          <div class="layui-upload-list">
            <img class="layui-upload-img" id="demo1" src="/static/public/img/QR_code/<?php echo htmlentities($data['img']); ?>">
            <p id="demoText"></p>
          </div>
        </div> 
    </div>
    <script type="text/javascript">
      $(".account").change(function(){
        $.ajax({
          url: '<?php echo url("sub/company_edit_acconut"); ?>',
          type: 'post',
          dataType: 'json',
          data: {"content": $(this).val()},
          success:function(msg){
            if(msg.flag=="true"){
              layer.msg("修改成功");
            }else{
              layer.msg(msg.msg);
            }
          }
        });
      })
      $(".qq").change(function(){
        $.ajax({
          url: '<?php echo url("sub/company_edit_qq"); ?>',
          type: 'post',
          dataType: 'json',
          data: {"content": $(this).val()},
          success:function(msg){
            if(msg.flag=="true"){
              layer.msg("修改成功");
            }else{
              layer.msg(msg.msg);
            }
          }
        });
      })
      $(".phone").change(function(){
        $.ajax({
          url: '<?php echo url("sub/company_edit_phone"); ?>',
          type: 'post',
          dataType: 'json',
          data: {"content": $(this).val()},
          success:function(msg){
            if(msg.flag=="true"){
              layer.msg("修改成功");
            }else{
              layer.msg(msg.msg);
            }
          }
        });
      })
      layui.use('upload', function(){
        var upload = layui.upload;     
          
        //普通图片上传
          var uploadInst = upload.render({
            elem: '#test1'
            ,url: '<?php echo url("sub/company_edit_img"); ?>'
            ,before: function(obj){
              //预读本地文件示例，不支持ie8
              obj.preview(function(index, file, result){
                $('#demo1').attr('src', result); //图片链接（base64）
              });
            }
          });
      });
    </script>
  </body>

</html>