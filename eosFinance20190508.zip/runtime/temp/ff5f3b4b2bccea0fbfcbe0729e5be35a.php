<?php /*a:1:{s:84:"E:\phpStudy\PHPTutorial\WWW\gongsi\eosFinance\application/admin/view\index\coin.html";i:1557304810;}*/ ?>
<html class="x-admin-sm">
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.1</title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body>
    <toolE>
      <div class="layui-upload" style="display: none" id="img_url_set">
        <div class="layui-upload-list">
          <img class="layui-upload-img" id="demo1" src="">
          <br />
          <p style="display: none" id="id"></p>
          <p style="display: none" id="name"></p>
          <button class="layui-btn" id="test1">修改图片</button>
        </div>
      </div>
    </tool>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">超级后台</a>
        <a href="">货币管理</a>
        <a>
          <cite>管理</cite>
        </a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <xblock>
        <button class="layui-btn" onclick="x_admin_show('添加用户','./coin_add.html')"><i class="layui-icon"></i>添加</button>
      </xblock>
      <table id="coin_list" lay-filter="coin_list" class="layui-table x-admin"></table>
      <script type="text/html" id="coin_switch">
        <input type="checkbox" lay-filter="amount" lay-skin="switch" lay-text="是|否" {{ d.amount==0 ? "" : "checked" }}>
      </script>
      <script type="text/html" id="coin_bar">
        <a onclick="member_stop(this,{{d.id}})" href="javascript:;"  title="{{d.state == '1' ? '使用中' : '已停用'}}"><i class="layui-icon">
          &#{{d.state == '1' ? 'xe601' : 'xe62f' }};
        </i></a>
      </script>
      <script type="text/html" id="coin_state">
        <span class="layui-btn layui-btn-normal layui-btn-mini {{d.state == '1' ? '' : 'layui-btn-disabled'}}">{{d.state == '1' ? '使用中'  : '已停用'}}</span>
      </script>
    </div>
    <script>
      layui.use(['table','form'],function(){
        var table = layui.table;
        var form = layui.form;
        table.render({
          elem: '#coin_list'
          ,height: 470
          ,url: '<?php echo url("json/coin"); ?>' //数据接口
          ,page: true //开启分页
          ,cols: [[ //表头
            {field: 'id', title: 'ID', width:80, sort: true, fixed: 'left'}
            ,{field: 'coin', title: '币名', width:100,edit:"text"}
            ,{field: 'min_unit', title: '最小单位', width:120,templet: '<div>小数点后{{d.min_unit}}位</div>',edit:"text"}
            ,{field: 'min_re', title: '最小充值金额', width:120,edit:"text"} 
            ,{field: 'max_re', title: '最大充值金额', width: 120, sort: true,templet:"<div>{{d.max_re==-1?'不限':d.max_re}}</div>",edit:"text"}
            ,{field: 'amount', title: '是否为小额货币', width: 130,toolbar:'#coin_switch'}
            ,{field: 'proportion', title: '与EOS的比例', width: 130, sort: true,edit:"text"}
            ,{field: 'img', title: '充值地址', width: 130,templet:"<div><img class='img_url' src='/static/public/img/QR_code/{{d.img}}' onclick='img_enlarge(this,\"{{d.id}}\",\"{{d.coin}}\")'></div>"}
            ,{field: 'state', title: '状态',toolbar:'#coin_state', width: 135}
            ,{title:'操作', toolbar: '#coin_bar'}
          ]]
        });
        table.on('edit(coin_list)', function(obj){
          switch(obj.field){
            case "coin":
              if(/^[A-Za-z]+$/.test(obj.value)){
                break;
              }else{
                layer.msg("请输入字母");
                return;
              }
            case "min_unit":
              if(/^0$|^[1-9]$|^([1-9][0-9])$/.test(obj.value)){
                break;
              }else{
                layer.msg("请输入100以内的正整数哦");
                return;
              }
              break;
            case "min_re":
              if(obj.value==-1){
                break;
              }

              if(/^(([^0][0-9]+|0)\.([0-9]{1,100})$)|^([^0][0-9]+|0)$/.test(obj.value)){
                break;
              }else{
                layer.msg("请输入数字");
                return;
              }
              break;
            case "max_re":
              if(obj.value==-1){
                break;
              }
              if(/^(([^0][0-9]+|0)\.([0-9]{1,100})$)|^([^0][0-9]+|0)$/.test(obj.value)){
                break;
              }else{
                layer.msg("请输入数字");
                return;
              }
              break;
            case "proportion":
              if(/^\d+(?:\.\d{0,5})?/.test(obj.value)){
                break;
              }else{
                layer.msg("请输入数字，不能低于小数点后5位哦");
                return;
              }
              break;
          }
          $.ajax({
            url: '<?php echo url("sub/coin_edit"); ?>',
            type: 'post',
            dataType: 'json',
            data: {"field": obj.field,"value":obj.value,"id":obj.data.id},
            success:function(msg){
              if(msg.flag=="true"){
                layer.msg("修改成功");
              }else{
                layer.msg("修改失败");
              }
            }
          });
        });
        form.on('switch(amount)', function(obj){
          var id=$(obj.othis[0]).closest("tr").children("td").first().text();
          $.ajax({
            url: '<?php echo url("sub/coin_edit_amount"); ?>',
            type: 'post',
            dataType: 'json',
            data: {"id":id,"state":obj.elem.checked},
            success:function(msg){
              if(msg.flag=="true"){
                layer.msg("修改成功");
              }else{
                  layer.msg(msg.msg);
              }
            }
          });
          
        });
      })
       /*用户-停用*/
      function member_stop(obj,id){
        if($(obj).attr('title')=='使用中'){
          layer.confirm('确认要停用吗？',function(index){
            //发异步把用户状态进行更改
            $.ajax({
              url: '<?php echo url("sub/coin_state_down"); ?>',
              type: 'post',
              dataType: 'json',
              data: {"id": id},
              success:function(msg){
                if(msg.flag=="true"){
                  $(obj).attr('title','已停用')
                  $(obj).find('i').html('&#xe62f;');
                  $(obj).parents("tr").find("[data-field='state']").find('span').addClass('layui-btn-disabled').html('已停用');
                  layer.msg('已停用!',{icon: 5,time:1000});
                }
              }
            });
            
          });
        }else if($(obj).attr('title')=='已停用'){
          layer.confirm('确认要启用吗？',function(index){
            $.ajax({
              url: '<?php echo url("sub/coin_state_up"); ?>',
              type: 'post',
              dataType: 'json',
              data: {"id": id},
              success:function(msg){
                if(msg.flag=='true'){
                  $(obj).attr('title','使用中')
                  $(obj).find('i').html('&#xe601;');
                  $(obj).parents("tr").find("[data-field='state']").find('span').removeClass('layui-btn-disabled').html('已启用');
                  layer.msg('已启用!',{icon: 1,time:1000});
                }
              }
            });
            
          });
        }else{
          layer.msg('请联系管理员!',{icon: 2,time:1000});
        }
      }
      function img_enlarge(obj,id,name){
        obj=$(obj);
        $("#demo1").attr("src",obj.attr("src"));
        $("#name").html(name);
        $("#id").html(id);
        layer.open({
          type: 1,
          title:name+"的支付二维码",
          content: $("#img_url_set"),
          area: ['auto','auto']
        });
      }
      layui.use('upload', function(){
          var upload = layui.upload;     
            var uploadInst = upload.render({
              elem: '#test1'
              ,url: '<?php echo url("sub/coim_repay_edit_img"); ?>'
              ,acceptMime: 'image/*'
              ,data: {
                name: function(){
                  return $('#name').html();
                },
                id :function(){
                  return $('#id').html();
                }
              }
              ,before: function(obj){
                //预读本地文件示例，不支持ie8
                obj.preview(function(index, file, result){
                  $('#demo1').attr('src', result); //图片链接（base64）
                });
              }
            });
        });
    </script>
  </body>

</html>