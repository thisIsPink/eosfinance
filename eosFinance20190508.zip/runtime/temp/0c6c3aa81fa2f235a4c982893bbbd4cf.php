<?php /*a:1:{s:87:"E:\phpStudy\PHPTutorial\WWW\gongsi\eosFinance\application/admin/view\index\bid_add.html";i:1555552736;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/public/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <script type="text/javascript" src="/static/admin/js/cookie.js"></script>
  </head>
  
  <body>
    <div class="x-body">
      <form class="layui-form">
        <div class="layui-form-item">
          <div class="layui-inline">
            <label class="layui-form-label">
              <span class="x-red">*</span>标题
            </label>
            <div class="layui-input-inline">
               <input type="text" id="title" name="title" required="" lay-verify="required" autocomplete="off" class="layui-input">
            </div>
          </div>
          <div class="layui-inline">
            <label class="layui-form-label">
              <span class="x-red">*</span>总额
            </label>
            <div class="layui-input-inline">
               <input type="text" id="total" name="total" required="" lay-verify="required" autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^\d+(?:\.\d{0,10})?/)'>
            </div>
          </div>
          <div class="layui-inline">
            <label class="layui-form-label">
              <span class="x-red">*</span>计息方式
            </label>
            <div class="layui-input-inline">
               <input type="text" value="按月付息,到期还本"  autocomplete="off" required="" lay-verify="required" class="layui-input" disabled>
            </div>
            <div class="layui-form-mid layui-word-aux">
              <span class="x-red">*</span>暂时不可修改
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-inline">
            <label class="layui-form-label"><span class="x-red">*</span>需求货币</label>
            <div class="layui-input-block">
              <div class="layui-input-inline" >
                <select class="coin_list" name="need" lay-search  required="" lay-verify="required" lay-filter="test">

                </select>
              </div>
            </div>
          </div>
          <div class="layui-inline">
            <label for="username" class="layui-form-label">
              <span class="x-red">*</span>结算币种
            </label>
            <div class="layui-input-inline" >
              <select class="coin_list" name="interest" required="" lay-verify="required" lay-search lay-filter="test">

              </select>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-inline">
            <label for="L_pass" class="layui-form-label">
              <span class="x-red">*</span>开始时间
            </label>
            <div class="layui-input-inline">
              <input class="layui-input" autocomplete="off" placeholder="开始时间" required="" lay-verify="required" name="start" id="start">
            </div>
          </div>
          <div class="layui-inline">
            <label for="L_repass" class="layui-form-label">
              <span class="x-red">*</span>停标时间
            </label>
            <div class="layui-input-inline">
              <input class="layui-input" autocomplete="off" placeholder="开始时间" required="" lay-verify="required" name="end" id="end">
            </div>
          </div>
          <div class="layui-inline">
            <label for="phone" class="layui-form-label">
              <span class="x-red">*</span>反款时间
            </label>
            <div class="layui-input-inline">
              <input class="layui-input" autocomplete="off" placeholder="开始时间" required="" lay-verify="required" name="repay" id="repay">
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <label for="L_pass" class="layui-form-label">
            <span class="x-red">*</span>相关资料
          </label>
          <div class="layui-input-inline" style="width: 720px">
            <textarea id="details" style="display: none;"></textarea>
          </div>
        </div>
        <div class="layui-form-item">
          <label for="L_pass" class="layui-form-label">
            <span class="x-red">*</span>基本信息
          </label>
          <div class="layui-input-inline" style="width: 720px">
            <textarea id="info" style="display: none;"></textarea>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-inline">
            <label for="L_pass" class="layui-form-label">
              <span class="x-red">*</span>年利率
            </label>
            <div class="layui-input-inline">
              <input type="text" id="profit" name="profit" required="" lay-verify="required" placeholder="%" autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^\d+(?:\.\d{0,10})?/)'>
            </div>
          </div>
          <div class="layui-inline">
            <label for="L_repass" class="layui-form-label">
              <span class="x-red">*</span>标类型
            </label>
            <div class="layui-input-inline">
              <select class="type" name="type" lay-search  required="" lay-verify="required">
                <option value="1">创建时固定反币数量</option>
                <option value="2">反币数量为返利时的比例</option>
              </select>
            </div>
          </div>
          <div class="layui-inline">
            <label for="L_pass" class="layui-form-label">预计反币量
            </label>
            <div class="layui-input-inline">
              <input type="text" name="expect" class="layui-input" disabled>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-inline">
            <label for="L_pass" class="layui-form-label">
              <span class="x-red">*</span>用途
            </label>
            <div class="layui-input-inline">
              <input type="text" id="purpose" name="purpose" required="" lay-verify="required" autocomplete="off" class="layui-input">
            </div>
          </div>
          <div class="layui-inline">
            <label for="L_repass" class="layui-form-label">
              <span class="x-red">*</span>最低投资金额
            </label>
            <div class="layui-input-inline">
              <input type="text" id="min_eos" name="min_eos" required="" lay-verify="required" autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^\d+(?:\.\d{0,2})?/)'>
            </div>
          </div>
          <div class="layui-inline">
            <label for="L_pass" class="layui-form-label">
              <span class="x-red">*</span>最高投资金额
            </label>
            <div class="layui-input-inline">
              <input type="text" id="max_eos" name="max_eos" required="" lay-verify="required" autocomplete="off" class="layui-input" oninput='this.value=this.value.toString().match(/^\d+(?:\.\d{0,2})?/)'>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <label for="L_repass" class="layui-form-label">
          </label>
          <button  class="layui-btn" lay-filter="add" lay-submit="">添加</button>
        </div>
      </form>
    </div>
    <script>
      var coin=null;
      layui.use(['form','layer','layedit','laydate'], function(){
        var form = layui.form
        ,layer = layui.layer
        ,laydate = layui.laydate
        ,layedit = layui.layedit;

        var buile_details=layedit.build('details',{tool: [
          'strong' //加粗
          ,'italic' //斜体
          ,'underline' //下划线
          ,'del' //删除线
          ,'|' //分割线
          ,'left' //左对齐
          ,'center' //居中对齐
          ,'right' //右对齐
          ,'link' //超链接
          ,'unlink' //清除链接
          ,'face' //表情
        ]}); //建立编辑器
        var buile_info=layedit.build('info',{tool: [
          'strong' //加粗
          ,'italic' //斜体
          ,'underline' //下划线
          ,'del' //删除线
          ,'|' //分割线
          ,'left' //左对齐
          ,'center' //居中对齐
          ,'right' //右对齐
          ,'link' //超链接
          ,'unlink' //清除链接
          ,'face' //表情
        ]});

        laydate.render({
          elem: '#start', //指定元素
          type: 'datetime'
        });
        laydate.render({
          elem: '#repay', //指定元素
          type: 'datetime'
          ,done: function(value){
            var end=Date.parse(new Date($('[name="end"]').val()));
            console.log(new Date(value)-end);
            if(new Date(value)-end<0){
              layer.msg("还款时间不能小于停标时间");
              return;
            }
            sel_money();
          }
        });
        laydate.render({
          elem: '#end', //指定元素
          type: 'datetime'
          ,done: function(value){
            var start=Date.parse(new Date($('[name="start"]').val()));
            console.log(new Date(value)-start);
            if(new Date(value)-start<0){
              layer.msg("停标时间不能小于开标时间");
              return;
            }
            sel_money();
          }
        });
        $.ajax({
          url: '<?php echo url("json/coin_list"); ?>',
          type: 'post',
          dataType: 'json',
          success:function(msg){
            coin=msg;
            var str='<option value="">请选择一个货币</option>';
            for(a in msg){
              str+='<option value="'+msg[a]["id"]+'">'+msg[a]["name"]+'</option>'
            }
            $(".coin_list").html(str);
            form.render('select');
          }
        });
          //监听提交
        form.on('submit(add)', function(data){
          console.log(data);
          var obj=data.field;
          obj.start=Date.parse(new Date(data.field.start))/1000;
          obj.repay=Date.parse(new Date(data.field.repay))/1000;
          obj.end=Date.parse(new Date(data.field.end))/1000;
          obj.details=layedit.getContent(buile_details);
          obj.info=layedit.getContent(buile_info);
          if(obj.end-obj.start<0||obj.repay-obj.end<0){
            layer.msg("请注意您填写的时间")
            return false;
          }
          $.ajax({
            url: '<?php echo url("sub/bid_add"); ?>',
            type: 'post',
            dataType: 'json',
            data: obj,
            success:function(msg){
              if(msg.flag=="true"){
                layer.alert("增加成功", {icon: 6},function () {
                    // 获得frame索引
                  var index = parent.layer.getFrameIndex(window.name);
                  //关闭当前frame
                  parent.layer.close(index);
                  x_admin_father_reload();
                });
              }else{
                layer.msg(msg.msg);
              }
            }
          });
          return false;
        });
        form.on('select(test)', function(data){
          sel_money();
        });
        $("#profit").change(function(){
          sel_money();
        })
        $("#total").change(function(){
          sel_money();
        })
      });
      function sel_money(){
        var total=$("#total").val();
        var need=$('[name="need"]').val();
        var interest=$('[name="interest"]').val();
        var profit=$('[name="profit"]').val();
        var repay=Date.parse(new Date($('[name="repay"]').val()))/1000;
        var end=Date.parse(new Date($('[name="end"]').val()))/1000;
        if(need==''||interest==''||profit==''||repay==''||end==''||total==''){
          return;
        }else{
          var c_need,c_interest;
          for(a in coin){
            if(coin[a]["id"]==need){
              c_need=coin[a];
            }
            if(coin[a]["id"]==interest){
              c_interest=coin[a];
            }
          }
          var total_day=Math.ceil((repay-end)/86400);
          var to_month=Math.floor(total_day/30);
          var to_day=total_day%30;
          var to_coin=(total/c_need["proportion"]*c_interest["proportion"]);
          var money=to_coin*profit/1200*to_month+to_coin*profit/36000*to_day;
          console.log(money);
          $("[name='expect']").val(money+' '+c_interest["name"])
        }
      }
    </script>
  </body>

</html>