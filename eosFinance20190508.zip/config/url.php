<?php
return [
	"qt"=>"http://192.168.1.199:8080",
	"ht"=>"http://www.eosfinance.com"
]
?>