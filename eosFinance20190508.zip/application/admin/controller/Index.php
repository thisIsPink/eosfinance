<?php
namespace app\admin\controller;

use think\Controller;
use app\admin\model\Bid_issuing;
use app\admin\model\Notice;
class Index extends Controller{
	public function login(){
		return $this->fetch();
	}
	public function index(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function welcome(){
		$data=[];
		$data["user_sum"]=db("user")->count();
		$data["user_hsum"]=db("user")->where("EOS_account","<>","null")->count();
		$data["user_invest"]=db("tender_record")->group("user_id")->count();
		$data["user_inviter"]=db("user")->where("inviter","<>","null")->count();
		$data["user_use"]=db("user")->where("state","2")->count();
		$data["user_dongjie"]=db("user")->where("state","3")->count();
		$this->assign("data",$data);
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function member_list(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function member_login_log(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function admin_list(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function admin_add(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function company(){
		$data=db("company")->field("account,qq,phone,img")->where("Id","1")->find();
		$this->assign("data",$data);
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function inviter(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function coin(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function coin_add(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function order_list(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function bid_edit(){
		$id=input("id");
		if($id!=null){
			$bid=new Bid_issuing;
			$data=$bid->sel_id($id);
			if($data){
				$this->assign("data",$data);
				if(is_login()){
					return $this->fetch();
				}else{
					$this->success('请登陆', 'index/login');
				}
			}
		}
	}
	public function bid_add(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function bid_tender_record(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function profit(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function repay(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function super_user(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function super_user_add(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function notice(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function notice_add(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function notice_edit(){
		$id=input("id");
		if($id!=null){
			$notice=new Notice;
			$data=$notice->sel_id($id);
			if($data){
				$this->assign("data",$data);
				if(is_login()){
					return $this->fetch();
				}else{
					$this->success('请登陆', 'index/login');
				}
			}
		}
	}
	public function notify(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function wheel_img(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function about(){
		$data=db("company")->field("about")->where("Id","1")->find();
		$this->assign("data",$data);
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function financial(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function operation_process(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function account_problem(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function security(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function help_info(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
	public function binding(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
		eospark();
	}
	public function recharge(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
		eospark();
	}
	public function cash(){
		if(is_login()){
			return $this->fetch();
		}else{
			$this->success('请登陆', 'index/login');
		}
	}
}
?>