<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
//查看ip
function ip() {
    if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $res =  preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
    return $res;
}
//获取浮点为小数点后几位
function getFloatLength($num) {
    $count = 0;
    $temp = explode ( '.', $num );
    if (sizeof ( $temp ) > 1) {
    $decimal = end ( $temp );
    $count = strlen ( $decimal );
    }
    return $count;
}
//判断用户是否登陆
function is_login(){
    if(session('?admin')){
        return true;
    }else{
        return false;
    }
}
//设置token
function set_token($user_id){
    $token=md5(time());
    db("user")->where("Id",$user_id)->update(["token"=>$token]);
    return $token;
}
//验证码token
function is_token($user_id,$token){
    $flag=db("user")->field("token")->where("Id",$user_id)->find();
    if($flag["token"]===$token){
        return true;
    }else{
        return false;
    }
}
//验证手机和邮箱
function mp_ver($name){
    $preg_email='/^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@([a-zA-Z0-9]+[-.])+([a-z]{2,5})$/ims';
    $preg_phone='/^1[34578]{1}\d{9}$/';
    if(preg_match($preg_email,$name)==0){
        if(preg_match($preg_phone,$name)==0){
            return false;
        }else{
            return "phone";
        }
    }else{
        return "email";
    }
}
//屏蔽邮箱和手机
function hideStar($str) { //用户名、邮箱、手机账号中间字符串以*隐藏 
    if (strpos($str, '@')) { 
        $email_array = explode("@", $str); 
        $prevfix = (strlen($email_array[0]) < 4) ? "" : substr($str, 0, 3); //邮箱前缀 
        $count = 0; 
        $str = preg_replace('/([\d\w+_-]{0,100})@/', '***@', $str, -1, $count); 
        $rs = $prevfix . $str; 
    } else { 
        $pattern = '/(1[3458]{1}[0-9])[0-9]{4}([0-9]{4})/i'; 
        if (preg_match($pattern, $str)) { 
            $rs = preg_replace($pattern, '$1****$2', $str); // substr_replace($name,'****',3,4); 
        } else { 
            $rs = substr($str, 0, 3) . "***" . substr($str, -1); 
        } 
    } 
    return $rs; 
}
//给手机发验证码
function phone_code($phone){
    $preg_phone='/^1[34578]{1}\d{9}$/';
    if(preg_match($preg_phone,$phone)!=0){
        $code = rand('100000','999999');
        cookie('phone_code', null);
        if(cache($phone)){
            return false;
        }
        //发送验证码
        set_cache($phone);
        cookie("phone",$phone);
        cookie("phone_code",$code);
        return $code;
    }else{
        return false;
    }
}
//发送邮箱验证码
function email_code($email){
    $preg_email='/^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@([a-zA-Z0-9]+[-.])+([a-z]{2,5})$/ims';
    if(preg_match($preg_email,$email)!=0){
        $code = rand('100000','999999');
        cookie('email_code', null);
        if(cache($email)){
            return false;
        }
        //发送验证码
        set_cache($email);
        cookie("email",$email);
        cookie("email_code",$code);
        return $code;
    }else{
        return false;
    }
}
//清除缓存
function del_code(){
    cookie("email_code",null);
    cookie("phone_code",null);
    cookie("phone",null);
    cookie("email",null);
}
//验证验证码
function ver_code($name,$code,$type){
    // var_dump(cookie("phone_code"));
    if($type=="phone"){
        if($code==cookie("phone_code")&&$name==cookie("phone")){
            del_code();
            return true;
        }
            
    }else if($type=="email"){
         if($code==cookie("email_code")&&$name==cookie("email")){
            del_code();
            return true;
         }
    }
    return false;
}
//设置验证码缓存
function set_cache($name){
    cache($name,time(),58);
}
//与时间相关
function time_inspect(){
    $time=time();
    $coin_list=db("coin")->field("Id,name,smallest_unit,proportion")->where("state","1")->select();
    //检查哪些标到结标时间了
    $end_bid=db("bid_issuing")->where("end_bid_time","<",$time)->where([["state","in","1,6"]])->select();
    if($end_bid!=null){
        foreach ($end_bid as $key => $value){
            if($value["state"]=="1"){
                //标未满过期并退钱
                foreach ($coin_list as $keys => $values) {
                    if($values["Id"]==$value["need_coin_id"]){
                        $coin_name=$values["name"];
                        break;
                    }
                }
                db("bid_issuing")->where("Id",$value["Id"])->update(["state"=>"5"]);
                //退钱
                $user=db("tender_record")->field("user_id,money")->where("bid_id",$value["Id"])->where("state","1")->select();
                foreach ($user as $keys => $values) {
                    $user_money=balance($values["user_id"]);
                    $user_money[$coin_name]["money"]=$user_money[$coin_name]["money"]+$values["money"];
                    db("user")->where("Id",$values["user_id"])->update(["money"=>json_encode($user_money)]);
                }
                db("tender_record")->where("bid_id",$value["Id"])->update(["state"=>'3']);
            }elseif($value["state"]=="6"){
                db("bid_issuing")->where("Id",$value["Id"])->update(["state"=>"7"]);
                //查看超级受益人的收益情况!!!!!!!!!!!!!!
                // $user_aggre=db("tender_record")->field("user_id,count(Id) a")->group("user_id")->select();
                // foreach ($user_aggre as $keys => $values) {
                //     if($values["a"]=='1'){

                //     }
                // }
            }
        }
    }
    //标吃利息
    $interest_bid=db("bid_issuing")->where([["FLOOR((".$time."-end_bid_time)/86400)%30","=",'0']])->where("state","7")->select();
    foreach ($interest_bid as $key => $value) {
        $day=floor(($time-$value["end_bid_time"])/86400);
        $flag=db("periods")->where("bid",$value["Id"])->where("phase",ceil($day/30))->find();
        if($flag!=null){
            break;
        }
        $small=0;//当前货币最小单位
        foreach ($coin_list as $keys => $values) {
            if($values["Id"]==$value["interest_coin_id"]){
                $small=$values["smallest_unit"];
                break;
            }
        }
        if($value["type"]=="1"){
            //固定标
            db("periods")->insert(["phase"=>ceil($day/30),"bid"=>$value["Id"],"time"=>$time,"money"=>num_point($value["total"]*30*($value["annual_profit"]/360/100)*$value["proportion"],$small),"day"=>'30',"state"=>"1"]);
        }
    }
    //标结束
    $repay_bid=db("bid_issuing")->where("state","7")->where("repayment_time","<",$time)->select();
    foreach ($repay_bid as $key => $value) {
        //求得标总时长
        $day=ceil(((int)$value["repayment_time"]-(int)$value["end_bid_time"])/86400);
        $flag=db("periods")->where("bid",$value["Id"])->where("phase",ceil($day/30))->find();
        if($flag!=null){
            break;
        }
        $small=0;//当前货币最小单位
        foreach ($coin_list as $keys => $values) {
            if($values["Id"]==$value["interest_coin_id"]){
                $small=$values["smallest_unit"];
                break;
            }
        }
        if($value["type"]=="1"){
            //固定标
            db("periods")->insert(["phase"=>ceil($day/30),"bid"=>$value["Id"],"time"=>$time,"money"=>num_point($value["total"]*($day%30)*($value["annual_profit"]/360/100)*$value["proportion"],$small),"day"=>$day%30,"state"=>"1"]);
        }
        //反本
        db("tender_record")->where("bid_id",$value["Id"])->update(["state"=>"2"]);
        db("bid_issuing")->where("Id",$value["Id"])->update(["state"=>"8"]);
    }
}
//去掉小数点后n位
function num_point($num,$n){
    return floor($num*pow(10,$n))/pow(10,$n);
}
//获取用户的余额
function balance($user_id){
    $money=db("user")->field("money")->where("Id",$user_id)->find()["money"];
    if($money==null){
        $money=[];
    }else{
        $money=json_decode($money,true);
    }
    $coin_list=db("coin")->field("name")->where("state","1")->select();
    if($money==[]){
        for($i=0;$i<count($coin_list);$i++) {
            $money[$coin_list[$i]["name"]]=["money"=>0,"frozen"=>0];
        }
    }else{
        foreach ($coin_list as $key => $value) {
            foreach($money as $keys=>$values){
                if($value["name"]==$keys){
                    break;
                }
                if($values==end($money)){
                    $money[$value["name"]]=["money"=>0,"frozen"=>0];
                }
            }
        }
    }
    db("user")->where("Id",$user_id)->update(["money"=>json_encode($money)]);
    return $money;
}
//把null转为0
function null_0($str){
    if($str==null){
        return 0;
    }else{
        return $str;
    }
}
//去eospark抓数据
function eospark(){
    $account=db("company")->field("account")->find(1)["account"];
    $info=file_get_contents('https://api.eospark.com/api?module=account&action=get_account_related_trx_info&apikey=b775cc21c752db60065cb6a71bc01c36&account='.$account.'&page=1&size=20');
    $info_arr=json_decode($info,true);
    if($info_arr["errno"]!='0'){
        return;       
    }
    $sum=$info_arr["data"]["trace_count"];
    //抓取没有抓过的东西
    $yes=0;
    if($info_arr["data"]["trace_list"]!=[]){
        foreach ($info_arr["data"]["trace_list"] as $key => $value) {
            $before=db("eospark")->where("trx_id",$value["trx_id"])->find();
            if($before==null){
                $time=strtotime("+8 hours",strtotime($value["timestamp"]));
                db("eospark")->insert(["trx_id"=>$value["trx_id"],"time"=>$time,"sender"=>$value["sender"],"receiver"=>$value["receiver"],"quantity"=>$value["quantity"],"memo"=>$value["memo"],"symbol"=>$value["symbol"],"status"=>$value["status"]]);
                if($value["sender"]==$account){
                    //提现
                }else if($value["receiver"]==$account){
                    //充币
                    $user=db("user")->field("Id,money,EOS_account")->where("tag",$value["memo"])->find();
                    if($user){
                        $is_coin=db("coin")->where("name",$value["symbol"])->where("state","1")->find();
                        //判断我们是否有这个币种
                        if($is_coin==null){
                            break;
                        }
                        if($is_coin["min_recharge"]>$value["quantity"]||($is_coin["max_recharge"]<$value["quantity"]&&$is_coin["max_recharge"]!='-1')){
                            //充值不在范围内
                            break;
                        }
                        $coin_id=coin_transformation($value["symbol"]);//币种id
                        //验证他是否绑定了eos
                        if($user["EOS_account"]!=null){
                            //绑定了就直接到冻结
                            $user_money=balance($user["Id"]);
                            $user_money[$value["symbol"]]["frozen"]+=$value["quantity"];
                            db("user")->where("Id",$user["Id"])->update(["money"=>json_encode($user_money)]);
                        }
                        //没绑定就只有记录
                        db("log_real")->insert(["type"=>'1','user'=>$user["Id"],'address'=>$value["sender"],'time'=>$time,'number'=>$value["quantity"],'coin'=>$coin_id,"fee"=>'0','txid'=>$value["trx_id"],'state'=>"1"]);
                    }
                }
            }else{
                $yes++;
            }
        }
    }else{
        return;
    }
    return;
    if($yes!=20){
        for($i=2;$i<ceil($sum/20);$i++){
            if($yes==20){
                //如果一页都重复了的话那就不在请求了;
                return;
            }
            $yes=0;
            if($info_arr["data"]["trace_list"]!=[]){
                foreach ($info_arr["data"]["trace_list"] as $key => $value) {
                    $before=db("eospark")->where("trx_id",$value["trx_id"])->find();
                    if($before==null){
                        $time=strtotime("+8 hours",strtotime($value["timestamp"]));
                        db("eospark")->insert(["trx_id"=>$value["trx_id"],["time"]=>$time,"sender"=>$value["sender"],"receiver"=>$value["receiver"],"quantity"=>$value["quantity"],"memo"=>$value["memo"],"symbol"=>$value["symbol"],"status"=>$value["status"]]);
                        if($value["sender"]==$account){
                            //提现
                        }else if($value["receiver"]==$account){
                            //充币
                            $user=db("user")->field("Id,money,EOS_account")->where("tag",$value["memo"])->find();
                            if($user){
                                $is_coin=db("coin")->where("name",$value["symbol"])->where("state","1")->find();
                                //判断我们是否有这个币种
                                if($is_coin==null){
                                    break;
                                }
                                if($is_coin["min_recharge"]>$value["quantity"]||($is_coin["max_recharge"]<$value["quantity"]&&$is_coin["max_recharge"]!='-1')){
                                    //充值不在范围内
                                    break;
                                }
                                $coin_id=coin_transformation($value["symbol"]);//币种id
                                //验证他是否绑定了eos
                                if($user["EOS_account"]!=null){
                                    //绑定了就直接到冻结
                                    $user_money=balance($user["Id"]);
                                    $user_money[$coin_id]["frozen"]+=$value["quantity"];
                                    db("user")->where($user["Id"])->update("money",json_encode($user_money));
                                }
                                //没绑定就只有记录
                                db("log_real")->insert(["type"=>'1','user'=>$user["Id"],'address'=>$value["sender"],'time'=>$time,'number'=>$value["quantity"],'coin'=>$coin_id,"fee"=>'0','txid'=>$value["trx_id"],'state'=>"1"]);
                            }
                        }
                    }else{
                        $yes++;
                    }
                }
            }else{
                return;
            }
        }
    }
    echo "string";
}
//币名转ID
function coin_transformation($name,$id=false){
    $coin_list=db("coin")->field("Id,name")->select();
    foreach ($coin_list as $key => $value) {
        if($id){
            if($value["Id"]==$name){
                return $value["name"];
            }
        }else{
            if($value["name"]==$name){
                return $value["Id"];
            }
        }
    }
    return false;
}
//用户检查
function user_inspect($id,$set=false){
    $user=db('user')->field("EOS_account,phone,email")->where("Id",$id)->find();
    if($user){
        if($user["EOS_account"]!=null&&$user["phone"]!=null&&$user["email"]!=null){
            if($set){
                db('user')->where("Id",$id)->update(["state"=>'2']);
            }
            return true;
        }
    }
    return false;
}