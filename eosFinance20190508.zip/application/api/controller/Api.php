<?php
namespace app\api\controller;
use think\Controller;
use app\sel\controller\Msg;
class Api extends Controller{
	private $arr_str=["code"=>420,"msg"=>'',"data"=>[]];
	private function state_fwq(){
		$this->arr_str["code"]=500;
	}
	private function state_ok(){
		$this->arr_str["code"]=200;
	}
	private function set_data($data){
		$this->state_ok();
		$this->arr_str["data"]=$data;
	}
	private function is_out($data){
		if($data){
			$this->set_data($data);
		}else{
			$this->state_fwq();
		}
		echo json_encode($this->arr_str);
		time_inspect();
		eospark();
	}
	private function out(){
		echo json_encode($this->arr_str);
		time_inspect();
		eospark();
	}
	public function api(){
		return $this->fetch();
	}
	//首页内容
	public function index(){
		$msg=new Msg;
		$img=$msg->wheel_img(6);
		foreach ($img as $key => $value) {
			$img[$key]["image"]=config("url.")["ht"]."/static/public/img/wheel/".$value["image"];
		}
		$trading_amount=$msg->trading_amount();
		$areate_amount=$msg->areate_amount();
		$repayment=$msg->repayment();
		$investment_msg=$msg->investment_msg();
		$money=30;
		$data=["trading_amount"=>["EOS"=>$trading_amount,"money"=>$money*$trading_amount],"areate_amount"=>["EOS"=>$areate_amount,"money"=>$money*$areate_amount],"repayment"=>["EOS"=>$repayment,"money"=>$money*$repayment],"img"=>$img,"investment_msg"=>$investment_msg];
		$this->is_out($data);
	}
	//关于我们
	public function about(){
		$msg=new Msg;
		$data=$msg->about();
		$this->is_out($data["about"]);
	}
	//标列表
	public function bid_list(){
		$msg=new Msg;
		$page=input("page")?input("page"):1;
		$limit=input('limit')?input("limit"):20;
		$type=input("type");
		if($type==null){
			$one=$msg->credit_bid($page,$limit,'1');
			$one_sum=$msg->sum_bid("1")/$limit;
			$two=$msg->credit_bid($page,$limit,'2');
			$two_sum=$msg->sum_bid("2")/$limit;
			if(is_array($one)&&is_array($two)){
			// $data=[["type"=>"1","data"=>$one,"title"=>"信用标","page"=>$page,"max_page"=>ceil($one_sum)],["type"=>"2","data"=>$two,"title"=>"活动标","page"=>(int)$page,"max_page"=>ceil($two_sum)]];
			$data=[["type"=>"1","data"=>$one,"title"=>"信用标","page"=>$page,"max_page"=>ceil($one_sum)]];
			}else{
				$data=false;
			}
		}else{
			switch ($type) {
				case '1':
					$title="信用表";
					break;
				case '2':
					$title="活动标";
					break;
				default:
					$this->out();
					return;
			}
			$sum=$msg->sum_bid($type);
			$datas=$msg->credit_bid($page,$limit,$type);
			$data=["type"=>$type,"data"=>$datas,"title"=>$title,"page"=>(int)$page,"max_page"=>ceil($sum/$limit)];
		}
		$this->is_out($data);
	}
	//标详情
	public function bid_info(){
		$id=input("id");
		if($id==null){
			$this->out();
		}else{
			$msg=new Msg;
			$info=$msg->bid_info($id);
			$details=$msg->bid_details($id);
			$recode=$msg->bid_recode($id,1,20);
			$cycle=$msg->bid_cycle($id,1,20);
			if($info){
				$data=["info"=>$info,"details"=>$details,"recode"=>$recode,"cycle"=>$cycle];
			}
			$this->is_out($data);
		}
	}
	//帮助信息
	public function help(){
		$msg=new Msg;
		$financial=$msg->help_financial();
		$operation=$msg->help_operation();
		$account=$msg->help_account();
		$security=$msg->help_security();
		$information=$msg->information();
		if($financial||$operation||$account||$security||$information){
			$data=["list"=>["financial"=>$financial],"operation"=>'http://192.168.1.50'.$operation,"account"=>$account["up"],"security"=>$security["up"],"information"=>$information];
			// $data["list"]=array_merge($data["list"],$account["down"],$security["down"]);
			foreach ($account["down"] as $key => $value) {
				$data["list"][$key]=$value;
			}
			foreach ($security["down"] as $key => $value) {
				$data["list"][$key]=$value;
			}
		}else{
			$data=false;
		}
		$this->is_out($data);
	}
	//用户余额
	public function per_order(){
		$msg=new Msg;
		if (session("index_user")!=null) {
			$this->is_out($msg->balance(session("index_user")));
		}else{
			$this->out();
		}
		
	}
	//收益排行榜
	public function ranking(){
		$msg=new Msg;
		$interest_ranking=$msg->interest_ranking(1,20);//利息收益
		$inv_ranking=$msg->invitation_ranking(1,20);//邀请人收益
		$data=["int"=>$interest_ranking,"inv"=>$inv_ranking];
		$this->set_data($data);
		$this->out();
	}
	//输出图片
	public function create(){
        // // 自定义二维码配置
        
        header('Content-Type: image/png');
        $config = [
            'title'         => true,
            'title_content' => '快来加入把',
            'logo'          => true,
            'logo_url'      => './static/public/img/logo.jpg',
            'logo_size'     => 400,
        ];

        // 直接输出
        $qr_url = config("url.")["qt"].'?invite='.input("inv");
        var_dump($qr_url);
        $qr_code = new QrcodeServer($config);
        $qr_img = $qr_code->createServer($qr_url);
        ob_clean();
        echo $qr_img;

        // 写入文件
        // $qr_url = '这是个测试二维码';
        // $file_name = './static/qrcode';  // 定义保存目录

        // $config['file_name'] = $file_name;
        // $config['generate']  = 'writefile';
        // // header('Content-Type: '.$qrCode->getContentType());
        // $qr_code = new QrcodeServer($config);
        // $rs = $qr_code->createServer($qr_url);
        // print_r($rs);

        exit;
    }
    //投资记录(个人)
    public function investment_record(){
    	$page=input("page")==null?1:input("page");
    	$limit=input("limit")==null?20:input("limit");
    	$id=session("index_user");
    	if($id!=null){
    		$msg=new Msg;
    		$bid_log=$msg->bid_log($id,$page,$limit);//记录
    		$cum=$msg->bid_cum($id);//累计投资
    		$coll=$msg->bid_coll($id);//待收本金
    		$dis=$msg->bid_dis($id);//发放利息
    		// $coll_record=$msg->bid_coll_record($id);//代收利息
    		//！！！！！！！！！！！！！！！！！！！！！！！！现金比例
    		$data=["log"=>$bid_log,"cumulative"=>$cum,"collected"=>$coll,"distribute"=>$dis,"coll_record"=>$cum,"proportion"=>30];
    		$this->set_data($data);
    	}
    	$this->out();
    }
    //用户账户历史记录
    public function historical_record(){
    	$time=input("time")==null?9999999999:input("time");
    	$id=session("index_user");
    	if($id!=null){
    		$msg=new Msg;
    		$data=$msg->his_record($id,$time);
    		$this->set_data($data);
    	}
    	$this->out();
    }
    //公司账户充值信息
    public function recharge(){
    	$id=session("index_user");
    	if($id!=null){
    		$msg=new Msg;
    		$info=$msg->recharge_info();
    		$tag=$msg->user_tag($id);
    		$img=$msg->coin_address();
    		$url=config("url.")["ht"].'/static/public/img/QR_code/';
    		$arr=[];
    		foreach ($img as $key => $value) {
    			$arr[$value["name"]]=["min"=>$value["min_recharge"],"img"=>$url.$value["img"]];
    		}
    		$this->set_data(["account"=>$info["account"],"img"=>$arr,"tag"=>$tag]);
    	}
    	$this->out();
	}
	//绑定信息
	public function binding(){
		$id=session("index_user");
    	if($id!=null){
    		$msg=new Msg;
    		$info=$msg->recharge_info();
    		$tag=$msg->user_tag($id);
    		$this->set_data(["account"=>$info["account"],"img"=>config("url.")["ht"].'/static/public/img/QR_code/'.$info["img"],"tag"=>$tag]);
    	}
    	$this->out();
	}
}
?>	