<?php
namespace app\api\controller;
use think\Controller;
use app\sel\controller\Login_after;
use app\sel\controller\Msg;
class Login extends Controller{
	//420参数错误,431验证码错误,432账号已存在,433账号不存在,434账户名或密码错误,451信息不对称,200正常,500服务器错误
	private $arr_str=["code"=>420,"msg"=>'',"data"=>[]];
	private function state_fwq(){
		$this->arr_str["code"]=500;
		//服务器错误
	}
	private function state_ok(){
		$this->arr_str["code"]=200;
		//正常
	}
	private function set_token($data){
		$this->arr_str["data"]["token"]=$data;
	}
	//提示错误
	private function set_error($num){
		$this->arr_str["code"]=$num;
		$cuowu=config('errormsg.');
		$this->arr_str["msg"]=$cuowu["zn"][$num];
	}
	//警告
	private function warning($num){
		$this->arr_str["code"]=$num;
	}
	private function set_data($data){
		$this->state_ok();
		$this->arr_str["data"]=$data;
	}
	private function is_out($data){
		if($data){
			$this->set_data($data);
		}else{
			$this->state_fwq();
		}
		echo json_encode($this->arr_str);
	}
	private function out(){
		echo json_encode($this->arr_str);
	}
	public function get_code(){
		$name=input("name");
		$preg_email='/^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@([a-zA-Z0-9]+[-.])+([a-z]{2,5})$/ims';
		$preg_phone='/^1[34578]{1}\d{9}$/';
		if(preg_match($preg_email,$name)==0){
			if(preg_match($preg_phone,$name)==0){
				$this->out();
				return;
			}else{
				$code=phone_code($name);
			}
		}else{
			$code=email_code($name);
		}
		$this->is_out($code);
	}
	public function reg(){
		$name=input("name");
		$pwd=input("password");
		$code=input("code");
		$inviter=input("inviter");
		if($name!=null&&$pwd!=null&&$code!=null){
			$login=new Login_after;
			$type=mp_ver($name);
			if(ver_code($name,$code,$type)){
				$flag=$login->is_user($name,$type);
				if($flag){
					$this->set_error(432);
				}else{
					if($flag==null){
						$flags=$login->reg($name,$pwd,$type);
						if($flags){
							if($inviter!=null||$inviter!=''){
								$login->add_inviter($flags,$inviter);
							}
							$this->state_ok();
						}elseif($flags==null){
							$this->state_fwq();
						}
					}
				}
			}else{
				$this->set_error(431);
			}
		}
		$this->out();
	}
	public function login(){
		$name=input("name");
		$pwd=input("password");
		$preg_email='/^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@([a-zA-Z0-9]+[-.])+([a-z]{2,5})$/ims';
		$preg_phone='/^1[34578]{1}\d{9}$/';
		if(preg_match($preg_email,$name)==0){
			if(preg_match($preg_phone,$name)==0){
			}else{
				$type="phone";
			}
		}else{
			$type="email";
		}
		if(isset($type)){
			$login=new Login_after;
			$id=$login->login($name,$pwd,$type);
			if($id){
				$login->add_log_login($id);
				// $this->state_ok();
				session("index_user",$id);
				$nick=$login->sel($id,"nick,email,phone,pay_password,EOS_account account");
				$data=["user_info"=>["nick"=>$nick["nick"],"email"=>$nick["email"]?hideStar($nick["email"]):false,"phone"=>$nick["phone"]?hideStar($nick["phone"]):false,"pay_password"=>$nick["pay_password"]==null?false:true,"account"=>$nick["account"]?substr_replace($nick["account"], '****', 3, 4):false],"security"=>[]];
				$this->set_data($data);
				$this->set_token(set_token($id));
			}else{
				$this->set_error(434);
			}
		}
		$this->out();
	}
	public function message(){
		$msg=new Msg;
		$notice=$msg->notice();
		if(session("index_user")){
			$notify=$msg->notify();
			$message=$msg->message(session("index_user"));
			$user_data=["notify"=>$notify,"message"=>$message];
		}else{
			$user_data=false;
		}
		$data=["notice"=>$notice,"user_data"=>$user_data];
		$this->is_out($data);
	}
	public function notice_info(){
		$id=input("id");
		if($id!=null){
			$msg=new Msg;
			$data=$msg->notice_info($id);
			if($data){
				$this->set_data($data);
			}
		}
		$this->out();
	}
}
?>