<?php
namespace app\sel\model;
use think\Model;

class Message extends Model{
	public function sel($id,$page,$limit){
		return db("message")->where("user_id",$id)->order("time","desc")->page($page,$limit)->select();
	}
}
?>