<?php
namespace app\sel\controller;
use think\Controller;

class Index extends Controller{
	public function qiantai(){
		return $this->fetch();
	}
}
?>	